import React from "react";
const Footer = () => {
    return (
        <>
            <div className="footer">
                <div className="copyright">
                    <p className="theme-color">Copyright © 2022. All Rights Reserved By TIXME</p>
                </div>
            </div>
        </>
    )
}
export default Footer;