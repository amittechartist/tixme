import React, { useState, useEffect } from "react";
import AppLogo from '../../../common/logo.svg';
import Whitestart from '../../../common/icon/whitestart.svg';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import BluestarIcon from '../../../common/icon/locationstart.svg';
import facebookicon from '../../../common/icon/social/facebookicon.svg';
import Instagramicon from '../../../common/icon/social/instagramicon.svg';
import Whatsappicon from '../../../common/icon/social/whatsappicon.svg';
import Youtubeicon from '../../../common/icon/social/youtubeicon.svg';
import whitestart from '../../../common/icon/whitestart.svg';
import EllipseIcon from '../../../common/icon/Ellipse 5.svg';
import SubscribeBg from '../../../common/icon/Subscribe.svg';
import CheckboxIcon from '../../../common/icon/checkbox.svg';
import LogoIcon from '../../../common/icon/logoicon.svg';
import Whitestarbtn from '../../../component/Whitestarbtn';
import Tada from "react-reveal/Tada";
import Lottie from "lottie-react";
import TicketCart from '../../../lotte/ticketcart.json';
import { Link, useNavigate } from "react-router-dom";
import { app_url } from '../../../common/Helpers';
const Footer = () => {
    const navigate = useNavigate();
    const lottewidth = {
        width: 'auto',
        height: '120px'
    }
    const [ShowCart, setShowCart] = useState(false);
    function checkCart() {
        const cartCheck = localStorage.getItem('cart');
        if (cartCheck) {
            const { items, quantities } = JSON.parse(cartCheck);
            if (items.length > 0) {
                setShowCart(true)
            } else {
                setShowCart(false)
            }
        } else {
            setShowCart(false)
        }
    }
    setInterval(checkCart, 1000);
    function viewcart() {
        navigate(app_url + 'cart-details');
    }
    return (
        <>
            {ShowCart ? (<Lottie className="cart-box-show" onClick={() => viewcart()} title="View Cart" animationData={TicketCart} style={lottewidth} />) : ''}
            <Container>
                <div className="subsacribe-box">
                    <Tada><img src={LogoIcon} className="LogoIcon-footer" alt="" /></Tada>
                    <img src={SubscribeBg} className="SubscribeBg" alt="" />
                    <Row className="subsacribe-content">
                        <Col md={12}>
                            <div className="subsscribe-box-style">
                                <span>
                                    <img src={EllipseIcon} alt="" />
                                </span>
                                <span className="Want-to-receive"><span> Want to receive events &</span> <span> news and updates?</span></span>
                            </div>
                            <div className="ml-5">
                                <div className="mt-4 mb-4 subsscribe-form-input-area">
                                    <input className="footer-input" type="text" placeholder="Name" />
                                    <input className="footer-input" type="text" placeholder="Email ID" />
                                </div>
                                <div className="mb-4">
                                    <span><img className="mr-4" src={CheckboxIcon} alt="" />I agree with the <span className="theme-color">privacy statement</span></span>
                                </div>
                                <div className="subscribe-btn">
                                    <Link className="button-join" to={'/'}>
                                        <Whitestarbtn title={'Get the latest updates'} />
                                    </Link>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </div>
            </Container>
            <footer className="footer-container">
                <div className="footer-head">
                    <Container fluid>
                        <Row className="mb-5">
                            <Col md={12} className="">
                                <ul className="website_top_menu website_top_menu-footer text-center ">
                                    <li className="nav-item">
                                        <span className="">
                                            <img src={Whitestart} className="footer-star-icon" alt="" /> <span className="footer-title">Ready to host events ?</span>
                                        </span>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="button-join" to={'/'}>
                                            <span>
                                                <span className="bg-style-white btn-a"><img height={30} width={30} src={BluestarIcon} /></span>
                                                <span className="bg-style-white btn-b">Create Event</span>
                                                <span className="bg-style-white btn-c"><img height={30} width={30} src={BluestarIcon} /></span>
                                            </span>
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="button-join" to={'/'}>
                                            <span>
                                                <span className="bg-style-white btn-a"><img height={30} width={30} src={BluestarIcon} /></span>
                                                <span className="bg-style-white btn-b">Find Events</span>
                                                <span className="bg-style-white btn-c"><img height={30} width={30} src={BluestarIcon} /></span>
                                            </span>
                                        </Link>
                                    </li>
                                </ul>
                            </Col>
                        </Row>
                    </Container>
                    <Container fluid>
                        <Row className="footer-bottom-container">
                            <Col className="left-footer-logo-box" md={5}>
                                <div className="footer-left-box footer-box-style">
                                    <div className="mb-3"><img src={AppLogo} className="footer-logo" alt="" /></div>
                                    <div><p className="Welcome_to_text">Welcome to TIXME, where every ticket tells a story! Our<br />mission is to redefine events, making each occasion an<br />unforgettable and cherished memory.</p></div>
                                    <div className="footer-icon-container">
                                        <ul>
                                            <li className="d-inline-block">
                                                <img src={facebookicon} alt="" />
                                            </li>
                                            <li className="d-inline-block ml-3">
                                                <img src={Instagramicon} alt="" />
                                            </li>
                                            <li className="d-inline-block ml-3">
                                                <img src={Whatsappicon} alt="" />
                                            </li>
                                            <li className="d-inline-block ml-3">
                                                <img src={Youtubeicon} alt="" />
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="footer-short-text">
                                        <p>© 2023 Eventbrite</p>
                                    </div>
                                </div>
                            </Col>
                            <Col md={7} className="right-footer-logo-box">
                                <Row className="footer-right-box  footer-box-style">
                                    <Col md={6}>
                                        <span className="footer-box-style-title">Find Events</span>
                                        <ul>
                                            <li>Browse Online Events</li>
                                            <li>Get the Eventbrite App</li>
                                            <li><Link to={app_url + 'raise-ticket'}>Customer support</Link></li>
                                        </ul>
                                    </Col>
                                    <Col md={6}>
                                        <span className="footer-box-style-title">Connect With Us</span>
                                        <ul>
                                            <li>Report This Event</li>
                                            <li>Help Center</li>
                                            <li>Terms</li>
                                            <li>Privacy</li>
                                            <li>Accessibility</li>
                                            <li>Community Guidelines</li>
                                        </ul>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                    </Container>
                </div>
            </footer>
        </>
    )
}
export default Footer;